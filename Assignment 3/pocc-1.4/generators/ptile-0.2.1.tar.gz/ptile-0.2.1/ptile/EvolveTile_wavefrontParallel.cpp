# include <ptile/EvolveTile_wavefrontParallel.hpp>
# include <ptile/GenericUtility.hpp>

s_past_node_t* EvolveWavefrontTileGenerator::EvolveTileCodeGenerateForWavefrontParallelLoop (s_past_node_t* pointLoops, s_past_node_t* tileLoops, 
								s_past_node_t* tiledCode, s_ptile_options_t* options)
{

  // cout<<"Entered EvolveTileCodeGenerateForWavefrontParallelLoop()"<<endl;
   s_past_node_t* evolveCode = NULL;
	
   // Collect iterator names
   vector<string>* iteratorNames = GeneralUtilityClass::CollectIteratorNames(pointLoops);
   GeneralUtilityClass::RemoveDuplicatesInStringVector (iteratorNames);

/*
	if (wPTile >= wPTile_full)
	{
		T1c0_old = T1c0;
		T1c1_old = T1c1;
		T1c2_old = T1c2;
		wPTile_inflection = wPTile;
		// Change tile sizes, wPTile, wPTile_full here 
		wPTile_max = ub_expression;
	}

*/
   s_past_node_t* switchCode = GenerateSwitchCode (iteratorNames, tiledCode);

  // cout<<"Generated the switch code"<<endl;

   assert (PAST_NODE_IS_A (tiledCode, past_for));
   GeneralUtilityClass::GetLastNode (((s_past_for_t*) tiledCode)->body)->next = switchCode;

  // cout<<"Attached the switch code"<<endl;

	// Set parallel 'for' loop information
	((s_past_for_t*) tiledCode)->body = past_for_to_parfor (((s_past_for_t*) tiledCode)->body);

		
/*
AddPrologue () function adds the following statements:
int T1c0_prev;
int T1c1_prev;
int T1c2_prev;
int wPTile_min = wPTile_lb expression;
int wPTile_max = wPTile_ub expression;
int wPTile_full = wPTile_min;
int wPTile_inflection;

for (wPTile = wPTile_min; wPTile <= wPTile_max; wPTile++)
{

}

*/

  // cout<<"Adding prologue"<<endl;

   evolveCode = AddPrologue (iteratorNames, tiledCode, options);

  // cout<<"Added prologue"<<endl;

/*
AddScannedCheckInPointLoops() function generates the following point loops:

//Point loops
if (wPTile >= wPTile_full)
 {
    // existing point loops
 }
else
 {	
   if ( !((c0t1*T1c0+T1c0-1)+... <= w_inflection))
   {

	if ( !(((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) <= w_inflection))
 	{
		S1 (c0, c1, c2);
	}
   }
 }


*/
   AddScannedCheckInPointLoops (iteratorNames, evolveCode);

// Enclose everything in a block
	  /*{
	FILE* fp = fopen ("Output.c", "a");
	past_pprint (fp, evolveCode);
	fclose (fp);
  	  }*/

	return evolveCode;
}



/*
Function GenerateSwitchCode() returns:

	if (wPTile >= wPTile_full)
	{
		T1c0_old = T1c0;
		T1c1_old = T1c1;
		T1c2_old = T1c2;
		wPTile_inflection = wPTile;
		// Change tile sizes, wPTile, wPTile_full here 
		wPTile_max = ub_expression;
	}

*/
s_past_node_t* EvolveWavefrontTileGenerator::GenerateSwitchCode (vector<string>* iteratorNames, s_past_node_t* tileLoops)
{
	s_past_node_t* body = NULL;

/*
		T1c0_old = T1c0;
		T1c1_old = T1c1;
		T1c2_old = T1c2;

*/
	{

   int i;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// Tile size name
	string T1c0_old_name = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i) + GeneralUtilityClass::GetOld_suffix();
	s_past_node_t* T1c0_old = past_node_varref_create (symbol_add_from_char (NULL, T1c0_old_name.c_str()));

	string T1c0_name = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i);
	s_past_node_t* T1c0 = past_node_varref_create (symbol_add_from_char (NULL, T1c0_name.c_str()));

	// Assignment statement
        s_past_node_t* assignment = past_node_statement_create (past_node_binary_create (past_assign, T1c0_old, T1c0));

	if (body == NULL)
	{
		body = assignment;
	}// if (evolveCode == NULL)
	else
	{
		GeneralUtilityClass::GetLastNode (body)->next = assignment;
	}// else
   }// for (i = 0; i < iteratorNames->size(); ++i)

	}
	

/*
		wPTile_inflection = wPTile;
		// Change tile sizes, wPTile, wPTile_full here 
*/
	{
		s_past_node_t* wPTile = past_node_varref_create (symbol_add_from_char (NULL, GeneralUtilityClass::GetGlobalEstimateWavefrontName().c_str()));
		s_past_node_t* wPTile_inflection = past_node_varref_create (symbol_add_from_char (NULL, 
						(GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateInflection_suffix()).c_str()));  

		s_past_node_t* assignment = past_node_statement_create (past_node_binary_create (past_assign, wPTile_inflection, wPTile));

                string commentString = "\n\n/* Assign new tile sizes below.\nUpdate wPTile: wPTile = floor((w+1)/alpha_max - n)-1, \nUdate  wPTile_full: wPTile_full = ceil((w+n)/alpha_min)+1 \nwhere, alpha_max = max(T1c0/T1c0_old, T1c1/T1c1_old, T1c2/T1c2_old, ...) \n       alpha_min = min(T1c0/T1c0_old, T1c1/T1c1_old, T1c2/T1c2_old, ...) \n       n is the number of dimensions of the iteration space*/";

		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		assignment->metainfo = (void*) comment;

		GeneralUtilityClass::GetLastNode (body)->next = assignment;
	}


/*
T1c0 = T1c0;
T1c0 = T1c0;
T1c0 = T1c0;
wPTile = wPTile;
wPTile_full = wPTile_full;
*/
	{

   int i;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// T1c0
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i);

	// T1c0 = T1c0;
	s_past_node_t* assignment = past_node_statement_create (past_node_binary_create (past_assign, past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str())), 
									past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str()))));

	GeneralUtilityClass::GetLastNode (body)->next = assignment;	
   }// for (i = 0; i < iteratorNames->size(); ++i)

	// wPTile = wPTile;
	s_past_node_t* assignment = past_node_statement_create (past_node_binary_create (past_assign, past_node_varref_create (symbol_add_from_char (NULL,				GeneralUtilityClass::GetGlobalEstimateWavefrontName().c_str())), 
past_node_varref_create (symbol_add_from_char (NULL, GeneralUtilityClass::GetGlobalEstimateWavefrontName().c_str()))));
	GeneralUtilityClass::GetLastNode (body)->next = assignment;	

// wPTile_full = wPTile_full;
assignment = past_node_statement_create (past_node_binary_create (past_assign, past_node_varref_create (symbol_add_from_char (NULL,				(GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateFull_suffix()).c_str())), 
past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateFull_suffix()).c_str()))));
	GeneralUtilityClass::GetLastNode (body)->next = assignment;


		string commentString = "\n/* Assigning new tile sizes, updating wPTile, wPTile_full ends */\n";
		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		assignment->metainfo = (void*) comment;

	}

//	wPTile_max = ub_expression;
	{
	// wPTile_max
	s_past_node_t* wPTile_max = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateMax_suffix()).c_str()));

	assert (PAST_NODE_IS_A (tileLoops, past_for) || PAST_NODE_IS_A (tileLoops, past_parfor));
	// Assign wPTile_max
       s_past_node_t* wPTile_maxAssignment = past_node_statement_create (past_node_binary_create (past_assign, wPTile_max, 
									past_clone(((s_past_binary_t*)((s_past_for_t*) tileLoops)->test)->rhs)));
	GeneralUtilityClass::GetLastNode (body)->next = wPTile_maxAssignment;
	}

	s_past_node_t* switchCode = (s_past_node_t*) GetIfWPTtileFullOnwords (body);
	
		string commentString = "/* Switch code begins */\n";
		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		switchCode->metainfo = comment;

	return switchCode;

}// s_past_node_t* EvolveWavefrontTileGenerator::GenerateSwitchCode (vector<string>* iteratorNames, s_past_node_t* tileLoops)

/*
AddPrologue () function adds the following statements:
int T1c0_prev;
int T1c1_prev;
int T1c2_prev;
int wPTile_min = wPTile_lb expression;
int wPTile_max = wPTile_ub expression;
int wPTile_full = wPTile_min;
int wPTile_inflection;

for (wPTile = wPTile_min; wPTile <= wPTile_max; wPTile++)
{

}

*/


s_past_node_t* EvolveWavefrontTileGenerator::AddPrologue (vector<string>* iteratorNames, s_past_node_t* tiledCode, s_ptile_options_t* options)
{
	s_past_node_t* evolveCode = NULL;
/*
int T1c0_prev;
int T1c1_prev;
int T1c2_prev;
*/

  // cout<<"Adding T1c0_prev et al"<<endl;
  // cout<<"Number of iterators: "<<iteratorNames->size()<<endl;
   int i;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// cout<<"Iterator: "<<iteratorNames->at(i)<<endl;
	// Tile size name
	string variableName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i) + GeneralUtilityClass::GetOld_suffix();
	s_past_node_t* vard = past_node_varref_create (symbol_add_from_char (NULL, variableName.c_str()));
	// Tile size type
        s_past_node_t* type = past_node_varref_create (symbol_add_from_char (NULL, "int"));

	// cout<<"Creating Declaration statement"<<endl;
	// Declaration statement
        s_past_node_t* declStatement = past_node_statement_create (past_node_vardecl_create (past_node_type_create(type), vard));
	// cout<<"Created Declaration statement"<<endl;

	if (evolveCode == NULL)
	{
		evolveCode = declStatement;
	}// if (evolveCode == NULL)
	else
	{
		GeneralUtilityClass::GetLastNode (evolveCode)->next = declStatement;
	}// else

	// cout<<"Completed "<<i<<" iteration"<<endl;
   }// for (i = 0; i < iteratorNames->size(); ++i)

  // cout<<"Adding wPTile_min et al"<<endl;

/*
int wPTile_min = wPTile_lb expression;
int wPTile_max = wPTile_ub expression;
int wPTile_full = wPTile_min;
int wPTile_inflection;
*/

      {
	if (PAST_NODE_IS_A (tiledCode, past_for) ||  PAST_NODE_IS_A (tiledCode, past_parfor))
	{
		PAST_DECLARE_TYPED(for, wLoop, tiledCode);
		string wPTile ((char*) wLoop->iterator->name_str);
		
	// wPTile_min
	s_past_node_t* wPTile_min = past_node_varref_create (symbol_add_from_char (NULL, (wPTile + GeneralUtilityClass::GetGlobalEstimateMin_suffix()).c_str()));
	// wPTile_min type
	s_past_node_t* wPTile_min_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// wPTile_min declaration
	s_past_node_t* wPTile_min_declaration = 
	  past_node_vardecl_create (past_node_type_create(wPTile_min_type),wPTile_min);
	// Assign wPTile_min
       s_past_node_t* wPTile_minAssignment = past_node_statement_create (past_node_binary_create (past_assign, wPTile_min_declaration, past_clone(((s_past_binary_t*)wLoop->init)->rhs)));
	((s_past_binary_t*)wLoop->init)->rhs = past_clone (wPTile_min);
	GeneralUtilityClass::GetLastNode (evolveCode)->next = wPTile_minAssignment;


	// wPTile_max
	s_past_node_t* wPTile_max = past_node_varref_create (symbol_add_from_char (NULL, (wPTile + GeneralUtilityClass::GetGlobalEstimateMax_suffix()).c_str()));
	// wPTile_max type
	s_past_node_t* wPTile_max_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// wPTile_max declaration
	s_past_node_t* wPTile_max_declaration = 
	  past_node_vardecl_create (past_node_type_create(wPTile_max_type), wPTile_max);
	// Assign wPTile_max
       s_past_node_t* wPTile_maxAssignment = past_node_statement_create (past_node_binary_create (past_assign, wPTile_max_declaration, past_clone(((s_past_binary_t*)wLoop->test)->rhs)));
	((s_past_binary_t*)wLoop->test)->rhs = past_clone (wPTile_max);
	GeneralUtilityClass::GetLastNode (evolveCode)->next = wPTile_maxAssignment;

/* int wPTile_full = wPTile_min; */
	// wPTile_full
	s_past_node_t* wPTile_full = past_node_varref_create (symbol_add_from_char (NULL, (wPTile + GeneralUtilityClass::GetGlobalEstimateFull_suffix()).c_str()));
	// wPTile_full type
	s_past_node_t* wPTile_full_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// wPTile_full declaration
	s_past_node_t* wPTile_full_declaration = 
	  past_node_vardecl_create (past_node_type_create(wPTile_full_type), wPTile_full);

	// Assign wPTile_full
       s_past_node_t* wPTile_fullAssignment = past_node_statement_create (past_node_binary_create (past_assign, wPTile_full_declaration, wPTile_min));	
	GeneralUtilityClass::GetLastNode (evolveCode)->next = wPTile_fullAssignment;

	/* int wPTile_inflection; */
	// wPTile_inflection
	s_past_node_t* wPTile_inflection = past_node_varref_create (symbol_add_from_char (NULL, (wPTile + GeneralUtilityClass::GetGlobalEstimateInflection_suffix()).c_str()));
	// wPTile_full type
	s_past_node_t* wPTile_inflection_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// wPTile_full declaration
	s_past_node_t* wPTile_inflection_declaration = past_node_statement_create (past_node_vardecl_create (past_node_type_create(wPTile_inflection_type), wPTile_inflection));
	GeneralUtilityClass::GetLastNode (evolveCode)->next = wPTile_inflection_declaration;

	}// if (PAST_NODE_IS_A (tiledCode, past_for) ||  PAST_NODE_IS_A (tiledCode, past_parfor))

      }


	// cout<<"Attaching the 'tiledCode' to the end"<<endl;
	// Attach the 'tiledCode' to the end
	GeneralUtilityClass::GetLastNode (evolveCode)->next = tiledCode;

	evolveCode = past_node_block_create (evolveCode);
	return evolveCode;
}// s_past_node_t* EvolveWavefrontTileGenerator::AddPrologue (vector<string>* iteratorNames, s_past_node_t* tiledCode, s_ptile_options_t* options)



/*
AddScannedCheckInPointLoops() function generates the following point loops:

//Point loops
if (wPTile >= wPTile_full)
 {
    // existing point loops
 }
else
 {	
   if ( !((c0t1*T1c0+T1c0-1)+... <= w_inflection))
   {

	if ( !(((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) <= w_inflection))
 	{
		S1 (c0, c1, c2);
	}
   }
 }


*/
   void EvolveWavefrontTileGenerator::AddScannedCheckInPointLoops (vector<string>* iteratorNames, s_past_node_t* evolveCode)
  {

	 s_past_node_t* parentOfPointLoops = GetParentOfPointLoops (evolveCode);
         s_past_if_t* ifCondition = GetFullTileForWFullOnwards (iteratorNames, ((s_past_for_t*) parentOfPointLoops)->body);

	 ifCondition->else_clause = GetPartialTile (iteratorNames, GeneralUtilityClass::past_clone_WithSameCloogStatements (((s_past_for_t*) parentOfPointLoops)->body));

	((s_past_for_t*) parentOfPointLoops)->body = (s_past_node_t*) ifCondition;

	  /*{
	FILE* fp = fopen ("PointLoops.c", "a");
	past_pprint (fp, parentOfPointLoops);
	fclose (fp);
  	  }*/
  }// void EvolveWavefrontTileGenerator::AddScannedCheckInPointLoops (vector<string>* iteratorNames, s_past_node_t* evolveCode)

s_past_node_t* EvolveWavefrontTileGenerator::GetParentOfPointLoops (s_past_node_t*  evolveCode)
{
	s_past_node_t* parent = NULL;
	past_visitor (evolveCode, StoreParentOfPointLoops, (void*) &parent, NULL, NULL);
	return parent;
}// s_past_node_t* EvolveWavefrontTileGenerator::GetParentOfPointLoops (s_past_node_t*  evolveCode)


/*
void EvolveWavefrontTileGenerator::StoreParentOfPointLoops (s_past_node_t* node, void* data)
{

if (*((s_past_node_t**) data) == NULL) // If not already set
{
if (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor))
   {
	 if (((s_past_for_t*) node)->type == e_past_tile_loop)
	  {
		PAST_DECLARE_TYPED(for, tileLoop, node);
		if (PAST_NODE_IS_A (tileLoop->body, past_for) || PAST_NODE_IS_A (tileLoop->body, past_parfor))
		{			
			if (((s_past_for_t*) tileLoop->body)->type != e_past_tile_loop)
			{				
				*((s_past_node_t**) data) = node;
			}// if (((s_past_node_t*) tileLoop->body)->type == e_past_point_loop)
		}// if (PAST_NODE_IS_A (tileLoop->body, past_for) || PAST_NODE_IS_A (tileLoop->body, past_parfor))
		else
		{
			*((s_past_node_t**) data) = node;
		} // else
	  }// if ((s_past_for_t*) node)->type == e_past_tile_loop)
   }// if (data == NULL && (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor)))
}// if (*((s_past_node_t**) data) == NULL)
}// static void CollectOuterMostIteratorName (s_past_node_t* node, void* data)
*/



bool EvolveWavefrontTileGenerator::IsIteratorSuffix_t1(s_past_for_t* node)
{
   bool isSuffix_t1 = false;

  if (node != NULL)
  {
   s_symbol_t* var_node = node->iterator;
   string iteratorName = string((char*)var_node->name_str);
   string suffix("");

   if (iteratorName.length() >= 2)
  {
	suffix = iteratorName.substr(iteratorName.length()-2, 2);
	if (suffix == "t1")
  	{
		isSuffix_t1 = true;
	}// if (suffix == "t1")
  }

  }// if (node != NULL)


   return isSuffix_t1;
}// bool IsIteratorSuffix_t1(s_past_node_t* node)

void EvolveWavefrontTileGenerator::StoreParentOfPointLoops (s_past_node_t* node, void* data)
{

if (*((s_past_node_t**) data) == NULL) // If not already set
{
if (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor))
   {
	 if (((s_past_for_t*) node)->type == e_past_tile_loop)
	  {
		PAST_DECLARE_TYPED(for, tileLoop, node);
		if (PAST_NODE_IS_A (tileLoop->body, past_for) || PAST_NODE_IS_A (tileLoop->body, past_parfor))
		{			
			if (((s_past_for_t*) tileLoop->body)->type != e_past_tile_loop ||  
			 (((s_past_for_t*) tileLoop->body)->type == e_past_tile_loop && IsIteratorSuffix_t1((s_past_for_t*) tileLoop->body) == false))
			{				
				*((s_past_node_t**) data) = node;
			}// if (((s_past_node_t*) tileLoop->body)->type == e_past_point_loop)
		}// if (PAST_NODE_IS_A (tileLoop->body, past_for) || PAST_NODE_IS_A (tileLoop->body, past_parfor))
		else
		{
			*((s_past_node_t**) data) = node;
		} // else
	  }// if ((s_past_for_t*) node)->type == e_past_tile_loop)
   }// if (data == NULL && (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor)))
}// if (*((s_past_node_t**) data) == NULL)
}// void EvolveWavefrontTileGenerator::StoreParentOfPointLoops (s_past_node_t* node, void* data)


/*
The function returns:

if (wPTile >= wPTile_full))
{
	body;
}
*/
 s_past_if_t* EvolveWavefrontTileGenerator::GetFullTileForWFullOnwards (vector<string>* iteratorNames, s_past_node_t* fullTileBody)
{

	s_past_node_t* condition = GetIfWPTtileFullOnwordsCondition();	
	s_past_if_t* ifCondition = past_if_create (condition, fullTileBody, NULL);
	
	return ifCondition;
}//  s_past_node_t* EvolveWavefrontTileGenerator::GetFullTileForWFullOnwards (s_past_for_t* fullTileBody)


/*
GetIfWPTtileFullOnwords() returns:
if (wPTile >= wPTile_full)
{
	body;
}

*/
 s_past_if_t* EvolveWavefrontTileGenerator::GetIfWPTtileFullOnwords (s_past_node_t* fullTileBody)
{
	s_past_node_t* condition = GetIfWPTtileFullOnwordsCondition();
	s_past_if_t* ifCondition = past_if_create (condition, fullTileBody, NULL);
	
	return ifCondition;
}//  s_past_node_t* EvolveWavefrontTileGenerator::GetIfWPTtileFullOnwords (s_past_for_t* fullTileBody)


/*
GetIfWPTtileFullOnwordsCondition() returns:
wPTile >= wPTile_full
*/
 s_past_node_t* EvolveWavefrontTileGenerator::GetIfWPTtileFullOnwordsCondition ()
{

	string wPTile_name = GeneralUtilityClass::GetGlobalEstimateWavefrontName();
	string wPTile_full_name = GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateFull_suffix();
	s_past_node_t* wPTile = past_node_varref_create (symbol_add_from_char (NULL, wPTile_name.c_str()));
	s_past_node_t* wPTile_full = past_node_varref_create (symbol_add_from_char (NULL, wPTile_full_name.c_str()));
	s_past_node_t* condition = past_node_binary_create(past_geq, wPTile, wPTile_full);
	return condition;
}//  s_past_if_t* EvolveWavefrontTileGenerator::GetIfWPTtileFullOnwordsCondition ()

/*
GetPartialTile() function produces the following:
   if (c0*T10/T1c0_old + .. > w_inflection)
   {
	S1 (c0, ..);
   }
   else
   {
	   if ( !((c0t1*T1c0+T1c0-1)/T1c0_old+... <= w_inflection))
	   {

		if ( ((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) > w_inflection)
 		{
			S1 (c0, c1, c2);
		}
	   }
   }

*/
s_past_node_t* EvolveWavefrontTileGenerator::GetPartialTile (vector<string>* iteratorNames, s_past_node_t* body)
{	
	s_past_node_t* partialTile = GetFullTileInChangeOverRegion (iteratorNames, GeneralUtilityClass::past_clone_WithSameCloogStatements (body));
	s_past_node_t* check = GeneratePointLoopCheck (iteratorNames);
	s_past_node_t* grandCheck = GeneratePointLoopEnteringCheck (iteratorNames);

/*
	if ( ((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) > w_inflection)
 	{
		S1 (c0, c1, c2);
	}
*/
	// printf ("Calling InsertPointLoopCheckBeforeCloogStatements()\n");
	InsertPointLoopCheckBeforeCloogStatements (check, body);
	// printf ("Returned from InsertPointLoopCheckBeforeCloogStatements()\n");

	s_past_node_t* partialTileElsePart = past_node_if_create (grandCheck, body, NULL); 
	((s_past_if_t*) GeneralUtilityClass::GetLastNode (partialTile))->else_clause = partialTileElsePart;

	return partialTile;
}// s_past_node_t* EvolveWavefrontTileGenerator::GetPartialTile (vector<string>* iteratorNames, s_past_node_t* body)

/*
GetFullTileInChangeOverRegion () returns:
int local_c0 = c0*T10;
int local_c1 = c1*T11;
   if (local_c0/T1c0_old + .. > w_inflection)
   {
	S1 (c0, ..);
   }

*/
s_past_node_t* EvolveWavefrontTileGenerator::GetFullTileInChangeOverRegion (vector<string>* iteratorNames, s_past_node_t* body)
{

	// (c0t1*T1c0+ .. > wPTile_inflection)
	s_past_node_t* skipCondition = GenerateCheckSkippingCondition (iteratorNames);
	((s_past_if_t*) GeneralUtilityClass::GetLastNode (skipCondition))->then_clause = body;
	return skipCondition;
}// s_past_node_t* EvolveWavefrontTileGenerator::GetFullTileInChangeOverRegion (vector<string>* iteratorNames, s_past_node_t* body)

/*
	if ( ((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) > w_inflection)
 	{
		S1 (c0, c1, c2);
	}
*/
void EvolveWavefrontTileGenerator::InsertPointLoopCheckBeforeCloogStatements (s_past_node_t* check, s_past_node_t* body)
{
	past_visitor (body, AddCheckBeforeCloogStatement, (void*) check, NULL, NULL);
}// void InsertPointLoopCheckBeforeCloogStatements (s_past_node_t* check, s_past_node_t* body)


void EvolveWavefrontTileGenerator::AddCheckBeforeCloogStatement (s_past_node_t* node, void* data)
{
	if (PAST_NODE_IS_A (node, past_root))
	{
		if (PAST_NODE_IS_A (((s_past_root_t*) node)->body, past_cloogstmt))
		{
			((s_past_root_t*) node)->body = CreateIfNodeWithCheck (((s_past_root_t*) node)->body, (s_past_node_t*)data);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_root))
	else if (PAST_NODE_IS_A (node, past_block))
	{
		if (PAST_NODE_IS_A (((s_past_block_t*) node)->body, past_cloogstmt))
		{
			((s_past_block_t*) node)->body = CreateIfNodeWithCheck (((s_past_block_t*) node)->body, (s_past_node_t*)data);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_block))
	else if (PAST_NODE_IS_A (node, past_for) || PAST_NODE_IS_A (node, past_parfor))
	{
		if (PAST_NODE_IS_A (((s_past_for_t*) node)->body, past_cloogstmt))
		{
			((s_past_for_t*) node)->body = CreateIfNodeWithCheck (((s_past_for_t*) node)->body, (s_past_node_t*)data);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_for))
}// void EvolveWavefrontTileGenerator::AddCheckBeforeCloogStatement (s_past_node_t* node, void* data)

/*
CreateIfNodeWithCheck() returns:
if (condition)
{
  body;
}

*/
s_past_node_t* EvolveWavefrontTileGenerator::CreateIfNodeWithCheck (s_past_node_t* body, s_past_node_t* condition)
{
	// printf ("Entered CreateIfNodeWithCheck()\n");
	s_past_node_t* returnNode = past_node_if_create (past_clone (condition), body, NULL);
	// printf ("Returning from CreateIfNodeWithCheck()\n");
	return returnNode;
}// s_past_node_t* EvolveWavefrontTileGenerator::CreateIfNodeWithCheck (s_past_node_t* body, s_past_node_t* condition)


/*
GeneratePointLoopCheck() generates:
((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) > w_inflection
*/
s_past_node_t* EvolveWavefrontTileGenerator::GeneratePointLoopCheck (vector<string>* iteratorNames)
{
	s_past_node_t* lhs = NULL;

   int i;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// T1c0_old
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i) + GeneralUtilityClass::GetOld_suffix();
	s_past_node_t* tileSize = past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str()));

	// c0
	s_past_node_t* pointIterator = past_node_varref_create (symbol_add_from_char (NULL, iteratorNames->at(i).c_str()));

	// c0/T1c0_old
	s_past_node_t* division = past_node_binary_create (past_div, pointIterator, tileSize);
	
	if (lhs == NULL)
	{
		lhs = division;
	}// if (lhs == NULL)
	else
	{
		// (c0/T1c0_old) + (c1/T1c1_old)
		lhs = past_node_binary_create (past_add, lhs, division);
	}
   }// for (i = 0; i < iteratorNames->size(); ++i)

	s_past_node_t* rhs = NULL;
	
	// w_inflection
	string w_inflection_name = GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateInflection_suffix();
	rhs = past_node_varref_create (symbol_add_from_char (NULL, w_inflection_name.c_str()));

	// ((c0/T1c0_old) + (c1/T1c1_old) + (c2/T1c2_old)) > w_inflection
	s_past_node_t* inequality = past_node_binary_create (past_gt, lhs, rhs);

	  /*{
	FILE* fp = fopen ("Condition.c", "a");
	fprintf (fp, "\n");
	past_pprint (fp, inequality);
	fprintf (fp, "\n");
	fclose (fp);
  	  }*/
	
	return inequality;
}// s_past_node_t* EvolveWavefrontTileGenerator::GeneratePointLoopCheck (vector<string>* iteratorNames)

/*
GeneratePointLoopEnteringCheck() generates:
((c0t1*T1c0+T1c0-1)/T1c0_old +... > w_inflection)
*/
s_past_node_t* EvolveWavefrontTileGenerator::GeneratePointLoopEnteringCheck (vector<string>* iteratorNames)
{
	s_past_node_t* lhs = NULL;

   int i;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// T1c0_old
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i) + GeneralUtilityClass::GetOld_suffix();
	s_past_node_t* tileSize = past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str()));

	// (c0t1*T1c0+T1c0-1)
	s_past_node_t* pointIterator = GeneralUtilityClass::GetTileBoundForIterator ((char*) iteratorNames->at(i).c_str(), 1, 1, 1);

	// (c0t1*T1c0+T1c0-1)/T1c0_old
	s_past_node_t* division = past_node_binary_create (past_div, pointIterator, tileSize);
	
	if (lhs == NULL)
	{
		lhs = division;
	}// if (lhs == NULL)
	else
	{
		// (c0/T1c0_old) + (c1/T1c1_old)
		lhs = past_node_binary_create (past_add, lhs, division);
	}
   }// for (i = 0; i < iteratorNames->size(); ++i)

	s_past_node_t* rhs = NULL;
	
	// w_inflection
	string w_inflection_name = GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateInflection_suffix();
	rhs = past_node_varref_create (symbol_add_from_char (NULL, w_inflection_name.c_str()));

	// (c0t1*T1c0+T1c0-1)/T1c0_old + ... > w_inflection
	s_past_node_t* inequality = past_node_binary_create (past_gt, lhs, rhs);

	  /*{
	FILE* fp = fopen ("Condition.c", "a");
	past_pprint (fp, inequality);
	fclose (fp);
  	  }*/
	
	return inequality;
}// s_past_node_t* EvolveWavefrontTileGenerator::GeneratePointLoopEnteringCheck (vector<string>* iteratorNames)


/*
GenerateCheckSkippingCondition() generates:
int local_c0 = c0t1*T1c0;
int local_c1 = c1t1*T1c1;

if (((local_c0)/T1c0_old +... > w_inflection))
{

}

*/
s_past_node_t* EvolveWavefrontTileGenerator::GenerateCheckSkippingCondition (vector<string>* iteratorNames)
{
	s_past_node_t* lhs = NULL;
	s_past_node_t* body = NULL;

   int i;
/*
int local_c0 = c0t1*T1c0;
int local_c1 = c1t1*T1c1;
*/	
   for (i = 0; i < iteratorNames->size(); ++i)
    {

	// local_c0
	s_past_node_t* local_c0 = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetLocalEstimatePrefix() + iteratorNames->at(i)).c_str()));
	// type
	s_past_node_t* type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// local_c0 declaration
	s_past_node_t* declaration = past_node_vardecl_create (past_node_type_create(type), local_c0);

	// (c0t1*T1c0)
	s_past_node_t* firstPointInTile = GeneralUtilityClass::GetTileBoundForIterator ((char*)iteratorNames->at(i).c_str(), -1, 1, 1);

	// int local_c0 = c0t1*T1c0;
	s_past_node_t* assignment = past_node_statement_create (past_node_binary_create (past_assign, declaration, firstPointInTile));

	if (i == 0)
	{
		body = assignment;
	}// if (i == 0)
	else
	{
		GeneralUtilityClass::GetLastNode (body)->next = assignment;
	}// else
    }// for (i = 0; i < iteratorNames->size(); ++i)

   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// T1c0_old
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i) + GeneralUtilityClass::GetOld_suffix();
	s_past_node_t* tileSize = past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str()));

	// local_c0
	s_past_node_t* pointIterator = GeneralUtilityClass::GetPastNodeFromString (GeneralUtilityClass::GetLocalEstimatePrefix() + iteratorNames->at(i), NULL);

	// (c0t1*T1c0)/T1c0_old
	s_past_node_t* division = past_node_binary_create (past_div, pointIterator, tileSize);
	
	if (lhs == NULL)
	{
		lhs = division;
	}// if (lhs == NULL)
	else
	{
		// (c0t1*T1c0/T1c0_old) + (c1t1*T1c1/T1c1_old)
		lhs = past_node_binary_create (past_add, lhs, division);
	}
   }// for (i = 0; i < iteratorNames->size(); ++i)

	s_past_node_t* rhs = NULL;
	
	// w_inflection
	string w_inflection_name = GeneralUtilityClass::GetGlobalEstimateWavefrontName() + GeneralUtilityClass::GetGlobalEstimateInflection_suffix();
	rhs = past_node_varref_create (symbol_add_from_char (NULL, w_inflection_name.c_str()));

	// (c0t1*T1c0)/T1c0_old + ... > w_inflection
	s_past_node_t* inequality = past_node_binary_create (past_gt, lhs, rhs);

	  /*{
	FILE* fp = fopen ("Condition.c", "a");
	past_pprint (fp, inequality);
	fclose (fp);
  	  }*/
	
	s_past_node_t* ifNode = past_node_if_create (inequality, NULL, NULL);
	GeneralUtilityClass::GetLastNode (body)->next = ifNode;

	return body;
}// s_past_node_t* EvolveWavefrontTileGenerator::GenerateCheckSkippingCondition (vector<string>* iteratorNames)




