/*
 * SecondLevelTiler.cpp: This file is part of the Parametric Tiling project.
 * 
 * Parametric Tiling: A CLAST-to-CLAST parametric tiling software
 * 
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 * 
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 * 
 * Author:
 * Sanket Tavargeri <sanket.tavargeri@gmail.com>
 * 
 */


# include <ptile/SecondLevelTiler.hpp>

struct TileLoops SecondLevelTiler::Tile(vector<Expression*> *exprs, s_ptile_options_t* options)
{
  Tiler tiler;
//  cout<<"Calling ConstructTiledIterationExpressions()"<<endl;
  vector<Expression*> *tileSpaceExpressions = ConstructTiledIterationExpressions(exprs);
//  cout<<"Returned from ConstructTiledIterationExpressions()"<<endl;
  struct TileLoops tileLoopsStruct; 

/*
   tileLoopsStruct = tiler.Tile(tileSpaceExpressions, options, 1, 2);
   cout<<"Printing second level tile loops"<<endl;
   past_pprint (stdout, tileLoopsStruct.tileLoops);
*/

  tileLoopsStruct.tileLoops = ASTGenerator::GenerateTileLoops(tileSpaceExpressions, options);
   
  past_visitor (tileLoopsStruct.tileLoops, ModifyIncrementSize, NULL, NULL, NULL);

//   cout<<"Printing second level tile loops"<<endl;
//   past_pprint (stdout, tileLoopsStruct.tileLoops);

  return tileLoopsStruct;
}// struct TileLoops SecondLevelTiler::Tile(vector<Expression*> *exprs, s_ptile_options_t* options)


vector<Expression*>* SecondLevelTiler::ConstructTiledIterationExpressions (vector<Expression*> *exprs)
{
   // cout<<"Entering ConstructTiledIterationExpressions"<<endl;

    vector<Expression*> *exprVec = new vector<Expression*>();

    // Collect the iterators
 //   cout<<"Calling ExpressionLibrary::FindIteratorNames()"<<endl;
    vector<string>* iterators = ExpressionLibrary::FindIteratorNames(exprs);
 //   cout<<"Returned from ExpressionLibrary::FindIteratorNames()"<<endl;

    int NumIterators = iterators->size();

    // cout<<"Iterators: "<<endl;
/*
    for (int i = 0; i < iterators->size(); i++)
    {
	cout<<iterators->at(i)<<endl;
    }
*/

/*
Introduce two expressions for each iterator, viz.,
i >= 0 and i <= T1c1. Equivalently i >= 0 -i + T1c1 >= 0
*/

  
    int NumExpressions = 2*NumIterators;

    // InterTileIterators
    for (int i = 0; i < NumIterators; i++)
      {
	    Expression* lb = new Expression();
	    Expression* ub = new Expression();

      {
	/* Expression: it2 >= 0. If there are 3 iterators - i, j and k - then the expression will be:
	   1 * i + 0 * j + 0 * k + 0 * T1i + 0 * T1j + 0 * T1k + 0
	*/
	Term *terms = new Term[2*NumIterators+1];
	string *paramNames = new string[2*NumIterators];
	
	for (int j = 0; j < NumIterators; j++)
	{
		paramNames[j] = ExpressionLibrary::GetTileSizePrefix(1, 2) + iterators->at(j);
	}// for (int j = 0; j < NumIterators; j++)

	for (int j = 0; j < NumIterators; j++)
	{
		paramNames[NumIterators+j] = ExpressionLibrary::GetTileSizePrefix(2, 2) + iterators->at(j);
	}// for (int j = 0; j < NumIterators; j++)

	// Setting default terms
	for (int j = 0; j < 2*NumIterators+1; j++)
	{
		terms[j].SetIdentityNumeratorDenominator(2*NumIterators, paramNames);
		
	}// for (int j = 0; j < 2*NumIterators+1; j++)

	// loop iterators
	for (int j = 0; j < NumIterators; j++)
	{
		terms[j].type = loop_iterator;
		terms[j].name = iterators->at(i) + ExpressionLibrary::GetTileIteratorSuffix(1, 2);

		if (i == j)
		{
			terms[j].coefficient = 1;
		}// if (i == j)
		else
		{
			terms[j].coefficient = 0;
		}//else
	}// for (int j = 0; j < NumIterators; j++)


	// parameters
	for (int j = 0; j < NumIterators; j++)
	{
		terms[NumIterators+j].type = parameter;
		terms[NumIterators+j].name = ExpressionLibrary::GetTileSizePrefix(1, 1) + iterators->at(i);
		terms[NumIterators+j].coefficient = 0;
	}// for (int j = 0; j < NumIterators; j++)

	terms[2*NumIterators].type = constant;
	terms[2*NumIterators].coefficient = 0;

	lb->terms = terms;
	lb->size = 2*NumIterators+1;
        exprVec->push_back(lb);
       }


      {
	/* Expression: -i + T1i >= 0. If there are 3 iterators - i, j and k - then the expression will be:
	   -1 * i + 0 * j + 0 * k + 1 * T1i + 0 * T1j + 0 * T1k + 0

           The polynomial will have tile sizes followed by parameters (outer level tile sizes)
           viz., T2i, T2j, T2k, T1i, T1j, T1k in that order.
	*/
	Term *terms = new Term[2*NumIterators+1];

	string *paramNames = new string[2*NumIterators];
	
	for (int j = 0; j < NumIterators; j++)
	{
		paramNames[j] = ExpressionLibrary::GetTileSizePrefix(1, 2) + iterators->at(j);
	}// for (int j = 0; j < NumIterators; j++)

	for (int j = 0; j < NumIterators; j++)
	{
		paramNames[NumIterators+j] = ExpressionLibrary::GetTileSizePrefix(2, 2) + iterators->at(j);
	}// for (int j = 0; j < NumIterators; j++)

	// Setting default terms
	for (int j = 0; j < 2*NumIterators+1; j++)
	{
		terms[j].SetIdentityNumeratorDenominator(2*NumIterators, paramNames);
		
	}// for (int j = 0; j < 2*NumIterators+1; j++)

	// loop iterators
	for (int j = 0; j < NumIterators; j++)
	{
		terms[j].type = loop_iterator;
		terms[j].name = iterators->at(i) + ExpressionLibrary::GetTileIteratorSuffix(1, 2);

		if (i == j)
		{
			terms[j].coefficient = -1;
		}// if (i == j)
		else
		{
			terms[j].coefficient = 0;
		}//else
	}// for (int j = 0; j < NumIterators; j++)


	// parameters
	for (int j = 0; j < NumIterators; j++)
	{
		terms[NumIterators+j].type = parameter;
		terms[NumIterators+j].name = ExpressionLibrary::GetTileSizePrefix(1, 1) + iterators->at(i);

		if (i == j)
		{
			terms[NumIterators+j].coefficient = 1;
		}// if (i == j)
		else
		{
			terms[NumIterators+j].coefficient = 0;
		}//else

	}// for (int j = 0; j < NumIterators; j++)

	terms[2*NumIterators].type = constant;
	terms[2*NumIterators].coefficient = -1;

	ub->terms = terms;
	ub->size = 2*NumIterators+1;
        exprVec->push_back(ub);
       }


      }//for (int i = 0; j < NumIterators; i++)


      // cout<<"Exiting ConstructTiledIterationExpressions"<<endl;
      return exprVec;
}// void SecondLevelTiler::ConstructTileIterationExpressions (vector<Expression*> *exprs)


  void SecondLevelTiler::ModifyBoundsOfPointLoopsForTwoLevelTiling(s_past_node_t* point_loops)
  {
        SecondLevelTiler::ModifyBoundsOfPointLoopsOuterTileLoopChecks(point_loops);
        SecondLevelTiler::ModifyBoundsOfPointLoops(point_loops);
  }//   void ModifyBoundsOfPointLoopsForTwoLevelTiling(s_past_node_t* point_loops)

  s_past_node_t* SecondLevelTiler::InsertTileLoops(s_past_node_t* point_loops,
		  struct TileLoops tileLoopsStruct1, struct TileLoops tileLoopsStruct2,
		  s_ptile_options_t* ptileOptions)
  {

    // 1. tileLoopsStruct1 (outer tile loops) <- tileLoopsStruct2 (inner tile loops) <- PointForLoop
    // 2. Replace the bounds of the point loop with mins and maxes appropriately

    s_past_node_t* tiledCode = NULL;
    TileLoopInserter tileLoopInserter;

    // 1. InnermostTiledForLoopNest.Body <- PointForLoop
    if (point_loops != NULL)
      {
	s_past_node_t* task_body = NULL;

	// 2. Replace the bounds of the point loop with mins and maxes appropriately
        ModifyBoundsOfPointLoopsOuterTileLoopChecks(point_loops);
        SecondLevelTiler::ModifyBoundsOfPointLoops(point_loops);

        task_body = point_loops;

        s_past_node_t* consolidatedForLoop = NULL;

	   if (ptileOptions->RSFME == 1)
	      {
		//printf("Calling CombineTileLoopsAndRSFMELoops()\n");
		consolidatedForLoop =
		  tileLoopInserter.CombineTileLoopsAndRSFMELoops(tileLoopsStruct1);
		//printf("Returned from CombineTileLoopsAndRSFMELoops()\n");
	      }// if (ptileOptions.RSFME == 1)
	    else
	      {
		consolidatedForLoop = tileLoopsStruct1.tileLoops;
	      }// else

	    s_past_for_t* innermostOuterTileLoop = (s_past_for_t*)
	      GeneralUtilityClass::FindInnermostForLoopInLoopNest
	      (consolidatedForLoop);
	    innermostOuterTileLoop->body = tileLoopsStruct2.tileLoops;

	    assert (tileLoopsStruct2.tileLoops != NULL);

	    s_past_for_t* innermostInnerTileLoop = (s_past_for_t*)
	      GeneralUtilityClass::FindInnermostForLoopInLoopNest(tileLoopsStruct2.tileLoops);

             innermostInnerTileLoop->body = task_body;

	    tiledCode = consolidatedForLoop;
      }// if (point_loops != NULL)


	// Erase loop numbering
	GeneralUtilityClass::DeNumberForLoopHierarchy (tiledCode);


    return tiledCode;
  }// s_past_node_t* SecondLevelTiler::InsertTileLoops()



  void SecondLevelTiler::ModifyBoundsOfPointLoopsOuterTileLoopChecks(s_past_node_t* PointLoops)
  {
    for ( ; PointLoops; PointLoops = PointLoops->next)
      {
	if (PAST_NODE_IS_A(PointLoops, past_for))
	  {
	    PAST_DECLARE_TYPED(for, LocalPointLoops, PointLoops);

	    s_past_node_t* LB = LocalPointLoops->init;
	    s_past_node_t* UB = LocalPointLoops->test;

	    /* 1. Extract the iterator name from expressions
	     * Assume that the expressions are of the form i = 0; i <= N. The LHS gives the iterator name
	     * 2. NewLB = (i = max(it1*T1i, LB)): Replace the RHS with the max of the original expression and it1*T1i
	     * 3. NewUB = (i <= min(it1*T1i + T1i - 1, N)) : Replace the RHS with the min of the original expression and it1*T1i + T1i - 1
	     */


	    const char * iterator =
	      (const char*)LocalPointLoops->iterator->data;

	    string tileIterator = string(iterator);
	    tileIterator += ExpressionLibrary::GetTileIteratorSuffix(1, 1);
	    string tileSize = string(iterator);
	    tileSize = ExpressionLibrary::GetTileSizePrefix(1, 1) + tileSize;

	    // Constructing the LB

/*
	    s_symbol_t* tisymb = symbol_add_from_char(NULL,
						      tileIterator.c_str());
	    s_past_node_t* tileIteratorClastName =
	      &past_varref_create(tisymb)->node;
	    s_symbol_t* tssymb = symbol_add_from_char(NULL,
						      tileSize.c_str());

	    s_past_node_t* tileSizeClastName =
	      &past_varref_create(tssymb)->node;

	    s_past_node_t* newLB =
	      &past_binary_create(past_mul, tileIteratorClastName,
				  tileSizeClastName)->node;
	    PAST_DECLARE_TYPED(binary, pb, LocalPointLoops->init);

	    pb->rhs = past_node_binary_create(past_max, newLB, pb->rhs);
*/

	    // Constructing the UB

	    s_symbol_t* tisymb = symbol_add_from_char(NULL, tileIterator.c_str());
	    s_past_node_t* tileIteratorClastName = &past_varref_create(tisymb)->node;
	    s_symbol_t* tssymb = symbol_add_from_char(NULL, tileSize.c_str());
	    s_past_node_t* tileSizeClastName = &past_varref_create(tssymb)->node;

	    s_past_node_t* newUB1 =
	      &past_binary_create(past_mul, tileIteratorClastName,
				  tileSizeClastName)->node;
	    s_past_node_t* minusOne = past_node_value_create_from_int(-1);

	    tssymb = symbol_add_from_char(NULL, tileSize.c_str());
	    tileSizeClastName = past_node_varref_create(tssymb);

	    s_past_node_t* newUB2 =
	      past_node_binary_create(past_add, tileSizeClastName, minusOne);

	    s_past_node_t* newUB =
	      &past_binary_create(past_add, newUB1, newUB2)->node;

	    PAST_DECLARE_TYPED(binary, pb2, LocalPointLoops->test);

	    pb2->rhs = past_node_binary_create(past_min, newUB, pb2->rhs);

	    ModifyBoundsOfPointLoopsOuterTileLoopChecks(LocalPointLoops->body);
	  }//if (CLAST_STMT_IS_A((struct clast_stmt*) tileLoops, stmt_for))
	 else if (PAST_NODE_IS_A(PointLoops,  past_affineguard))
	 {
	      PAST_DECLARE_TYPED(affineguard, IfConditionStmt, PointLoops);
              ModifyBoundsOfPointLoopsOuterTileLoopChecks(IfConditionStmt->then_clause);
	 }// else if (PAST_NODE_IS_A(PointLoops,  past_affineguard))
      }// for ( ; PointLoops; PointLoops = PointLoops->next)
  }//   void SecondLevelTiler::ModifyBoundsOfPointLoopsOuterTileLoopChecks(s_past_node_t* PointLoops)


  void SecondLevelTiler::ModifyBoundsOfPointLoops(s_past_node_t* PointLoops)
  {
    for ( ; PointLoops; PointLoops = PointLoops->next)
      {
	if (PAST_NODE_IS_A(PointLoops, past_for))
	  {
	    PAST_DECLARE_TYPED(for, LocalPointLoops, PointLoops);

	    s_past_node_t* LB = LocalPointLoops->init;
	    s_past_node_t* UB = LocalPointLoops->test;

	    /* 1. Extract the iterator name from expressions
	     * Assume that the expressions are of the form i = 0; i <= N. The LHS gives the iterator name
	     * 2. NewLB = (i = max(it1*T1i+it2, LB)): Replace the RHS with the max of the original expression and it1*T1i+it2*T2i
	     * 3. NewUB = (i <= min(it1*T1i+it2+T2i-1, N)) : Replace the RHS with the min of the original expression and it1*T1i+it2*T2i+T2i-1
	     */


	    const char * iterator =
	      (const char*)LocalPointLoops->iterator->data;

	    string tileIterator1 = string(iterator);
	    tileIterator1 += ExpressionLibrary::GetTileIteratorSuffix(2, 2);
	    string tileSize1 = string(iterator);
	    tileSize1 = ExpressionLibrary::GetTileSizePrefix(2, 2) + tileSize1;


	    string tileIterator2 = string(iterator);
	    tileIterator2 += ExpressionLibrary::GetTileIteratorSuffix(1, 2);
	    string tileSize2 = string(iterator);
	    tileSize2 = ExpressionLibrary::GetTileSizePrefix(1, 2) + tileSize2;


	    // Constructing the LB
	    s_symbol_t* tisymb1 = symbol_add_from_char(NULL,
						      tileIterator1.c_str()); // it1
	    s_past_node_t* tileIteratorClastName1 =
	      &past_varref_create(tisymb1)->node;

	    s_symbol_t* tssymb1 = symbol_add_from_char(NULL,
						      tileSize1.c_str()); // T1i

	    s_past_node_t* tileSizeClastName1 =
	      &past_varref_create(tssymb1)->node;

	    s_past_node_t* newLB_part1 =
	      &past_binary_create(past_mul, tileIteratorClastName1,
				  tileSizeClastName1)->node; // it1*T1i


	    s_symbol_t* tisymb2 = symbol_add_from_char(NULL,
						      tileIterator2.c_str()); // it2
	    s_past_node_t* tileIteratorClastName2 =
	      &past_varref_create(tisymb2)->node;

	    s_symbol_t* tssymb2 = symbol_add_from_char(NULL,
						      tileSize2.c_str()); // T2i

	    s_past_node_t* tileSizeClastName2 =
	      &past_varref_create(tssymb2)->node;

/*
	    s_past_node_t* newLB_part2 =
	      &past_binary_create(past_mul, tileIteratorClastName2,
				  tileSizeClastName2)->node; // it2*T2i 



	    s_past_node_t* newLB =
	      &past_binary_create(past_add, newLB_part1,
				  newLB_part2)->node; // it1*T1i + it2*T2i
*/

	    s_past_node_t* newLB =
	      &past_binary_create(past_add, newLB_part1,
				  tileIteratorClastName2)->node; // it1*T1i + it2



	    PAST_DECLARE_TYPED(binary, pb, LocalPointLoops->init);

	    pb->rhs = past_node_binary_create(past_max, newLB, pb->rhs);

	    // Constructing the UB

	    tisymb1 = symbol_add_from_char(NULL, tileIterator1.c_str()); // it1
	    tileIteratorClastName1 = &past_varref_create(tisymb1)->node;

	    tssymb1 = symbol_add_from_char(NULL, tileSize1.c_str()); // T1i
	    tileSizeClastName1 = &past_varref_create(tssymb1)->node;

	    tisymb2 = symbol_add_from_char(NULL, tileIterator2.c_str()); // it2
	    tileIteratorClastName2 = &past_varref_create(tisymb2)->node;

	    tssymb2 = symbol_add_from_char(NULL, tileSize2.c_str()); // T2i
	    tileSizeClastName2 = &past_varref_create(tssymb2)->node;


	    s_past_node_t* newUB1_part1 =
	      &past_binary_create(past_mul, tileIteratorClastName1,
				  tileSizeClastName1)->node; // it1*T1i

/*
	    s_past_node_t* newUB1_part2 =
	      &past_binary_create(past_mul, tileIteratorClastName2,
				  tileSizeClastName2)->node; // it2*T2i
*/



	    s_past_node_t* minusOne = past_node_value_create_from_int(-1); 

/*
	    s_past_node_t* newUB1 =
	      past_node_binary_create(past_add, newUB1_part1, newUB1_part2); // it1*T1i + it2*T2i
*/

	    s_past_node_t* newUB1 =
	      past_node_binary_create(past_add, newUB1_part1, tileIteratorClastName2); // it1*T1i + it2


	    tssymb2 = symbol_add_from_char(NULL, tileSize2.c_str()); // T2i
	    tileSizeClastName2 = past_node_varref_create(tssymb2);

	    s_past_node_t* newUB2 =
	      past_node_binary_create(past_add, tileSizeClastName2, minusOne); // T2i-1

	    s_past_node_t* newUB =
	      &past_binary_create(past_add, newUB1, newUB2)->node; // it1*T1i + it2*T2i + T2i - 1

	    PAST_DECLARE_TYPED(binary, pb2, LocalPointLoops->test);

	    pb2->rhs = past_node_binary_create(past_min, newUB, pb2->rhs);

	    ModifyBoundsOfPointLoops(LocalPointLoops->body);
	  }//if (CLAST_STMT_IS_A((struct clast_stmt*) tileLoops, stmt_for))
	 else if (PAST_NODE_IS_A(PointLoops,  past_affineguard))
	 {
	      PAST_DECLARE_TYPED(affineguard, IfConditionStmt, PointLoops);
              ModifyBoundsOfPointLoops(IfConditionStmt->then_clause);
	 }// else if (PAST_NODE_IS_A(PointLoops,  past_affineguard))
      }// for ( ; PointLoops; PointLoops = PointLoops->next)
  }// void ModifyBoundsOfPointLoops(struct ext_clast_for* PointLoops)



void SecondLevelTiler::ModifyIncrementSize (s_past_node_t* node, void* args)
{
  if (past_node_is_a (node, past_for))
   {
     PAST_DECLARE_TYPED(for, forLoop, node);
     assert (forLoop->iterator != NULL);
     const char *iterator = (const char*)forLoop->iterator->data;
     string iteratorName (iterator);

	// increment
	{
	// c1t2 = c1t2 + T2c1
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 2) +  iteratorName.substr (0, iteratorName.length() - 2); // stripping away 't2' suffix
	s_symbol_t* iterSymb1 = symbol_add_from_char (NULL, iteratorName.c_str());
	s_symbol_t* tileSizeSymb = symbol_add_from_char (NULL, tileSizeName.c_str());
	assert (tileSizeSymb != NULL);
	s_past_node_t* addition =  past_node_binary_create(past_add, &past_varref_create(iterSymb1)->node, &past_varref_create(tileSizeSymb)->node);

	s_symbol_t* iterSymb2 = symbol_add_from_char (NULL, iteratorName.c_str());
	s_past_node_t* assignment =  past_node_binary_create(past_assign, &past_varref_create(iterSymb2)->node, addition);
	forLoop->increment = assignment;
	}

   }// if (past_node_is_a (node, past_for))

}// void SecondLevelTiler::ModifyIncrementSize (s_past_node_t* node, void* args)


// Distributes the statements - doesn't fuse
  s_past_node_t* SecondLevelTiler::InsertTileLoopsInOriginalLoopOrder(s_past_node_t* point_loops,
		  struct TileLoops tileLoopsStruct1, struct TileLoops tileLoopsStruct2,
		  s_ptile_options_t* ptileOptions)
 {
	//  return SecondLevelTiler::InsertTileLoops(point_loops, tileLoopsStruct1, tileLoopsStruct2, ptileOptions);
	TileLoopInserter tileLoopInserter;
	s_past_node_t* tiledCode = NULL;
	// Insert inner tile loops first - c1t2 etc.
	tiledCode = tileLoopInserter.InsertTileLoopsInOriginalLoopOrder (point_loops, tileLoopsStruct1, ptileOptions, tileLoopsStruct2.tileLoops);

	// Insert outer tile loops next - c1t1 etc.
	// tiledCode = tileLoopInserter.InsertTileLoopsInOriginalLoopOrder (tiledCode, tileLoopsStruct1, ptileOptions, 1, 1);
	return tiledCode;
 }// s_past_node_t* SecondLevelTiler::InsertTileLoopsInOriginalLoopOrder()
