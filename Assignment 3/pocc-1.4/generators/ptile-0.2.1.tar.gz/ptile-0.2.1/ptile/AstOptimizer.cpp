#include <ptile/AstOptimizer.hpp>

s_past_node_t* AstOptimizer::HoistLoopBoundExpressions (s_past_for_t* forLoop)
{
	s_past_node_t* returnNode = NULL;
	string iteratorName ((char*) forLoop->iterator->data);
		
	// iteratorName_min
	s_past_node_t* iteratorName_min = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateMin_prefix() + iteratorName).c_str()));
	// iteratorName_min type
	s_past_node_t* iteratorName_min_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// iteratorName_min declaration
	s_past_node_t* iteratorName_min_declaration = 
	  past_node_vardecl_create (past_node_type_create(iteratorName_min_type), iteratorName_min);
	// Assign iteratorName_min
       s_past_node_t* iteratorName_minAssignment = past_node_statement_create (past_node_binary_create (past_assign, iteratorName_min_declaration, past_clone(((s_past_binary_t*)forLoop->init)->rhs)));
	((s_past_binary_t*)forLoop->init)->rhs = past_clone (iteratorName_min);
	returnNode = iteratorName_minAssignment;


	// iteratorName_max
	s_past_node_t* iteratorName_max = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateMax_prefix() + iteratorName).c_str()));
	// iteratorName_max type
	s_past_node_t* iteratorName_max_type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
	// iteratorName_max declaration
	s_past_node_t* iteratorName_max_declaration = past_node_vardecl_create (past_node_type_create(iteratorName_max_type), iteratorName_max);
	// Assign iteratorName_max
       s_past_node_t* iteratorName_maxAssignment = past_node_statement_create (past_node_binary_create (past_assign, iteratorName_max_declaration, past_clone(((s_past_binary_t*)forLoop->test)->rhs)));
	((s_past_binary_t*)forLoop->test)->rhs = past_clone (iteratorName_max);
	GeneralUtilityClass::GetLastNode (returnNode)->next = iteratorName_maxAssignment;

	GeneralUtilityClass::GetLastNode (returnNode)->next = (s_past_node_t*) forLoop;
	return returnNode;
}// s_past_node_t* AstOptimizer::HoistLoopBoundExpressions (s_past_for_t* forLoop)


s_past_node_t* AstOptimizer::HoistLoopBoundExpressionsWithoutDeclaration (s_past_for_t* forLoop)
{
	s_past_node_t* returnNode = NULL;
	string iteratorName ((char*) forLoop->iterator->data);
		
	// iteratorName_min
	s_past_node_t* iteratorName_min = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateMin_prefix() + iteratorName).c_str()));

	// Assign iteratorName_min
       s_past_node_t* iteratorName_minAssignment = past_node_statement_create (past_node_binary_create (past_assign, iteratorName_min, past_clone(((s_past_binary_t*)forLoop->init)->rhs)));
	((s_past_binary_t*)forLoop->init)->rhs = past_clone (iteratorName_min);
	returnNode = iteratorName_minAssignment;


	// iteratorName_max
	s_past_node_t* iteratorName_max = past_node_varref_create (symbol_add_from_char (NULL, (GeneralUtilityClass::GetGlobalEstimateMax_prefix() + iteratorName).c_str()));
	// Assign iteratorName_max
       s_past_node_t* iteratorName_maxAssignment = past_node_statement_create (past_node_binary_create (past_assign, iteratorName_max, past_clone(((s_past_binary_t*)forLoop->test)->rhs)));
	((s_past_binary_t*)forLoop->test)->rhs = past_clone (iteratorName_max);
	GeneralUtilityClass::GetLastNode (returnNode)->next = iteratorName_maxAssignment;

	GeneralUtilityClass::GetLastNode (returnNode)->next = (s_past_node_t*) forLoop;
	return returnNode;
}// s_past_node_t* AstOptimizer::HoistLoopBoundExpressionsWithoutDeclaration (s_past_for_t* forLoop)

void AstOptimizer::TraverseToHoistLoopBoundExpressions (s_past_node_t* node, void* data)
{

	if (PAST_NODE_IS_A (node, past_root))
	{
		if (PAST_NODE_IS_A (((s_past_root_t*) node)->body, past_for) || PAST_NODE_IS_A (((s_past_root_t*) node)->body, past_parfor))
		{
			((s_past_root_t*) node)->body = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_root_t*) node)->body);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_root))
	else if (PAST_NODE_IS_A (node, past_block))
	{
		if (PAST_NODE_IS_A (((s_past_block_t*) node)->body, past_for) || PAST_NODE_IS_A (((s_past_block_t*) node)->body, past_parfor))
		{
			((s_past_block_t*) node)->body = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_block_t*) node)->body);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_block))
	else if (PAST_NODE_IS_A (node, past_for) || PAST_NODE_IS_A (node, past_parfor))
	{
		if (PAST_NODE_IS_A (((s_past_for_t*) node)->body, past_for) || PAST_NODE_IS_A (((s_past_for_t*) node)->body, past_parfor))
		{
			((s_past_for_t*) node)->body = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_for_t*) node)->body);
		}// body is a 'for' loop

		if (PAST_NODE_IS_A (node->next, past_for) || PAST_NODE_IS_A (node->next, past_parfor))
		{
			node->next = HoistLoopBoundExpressionsWithoutDeclaration ((s_past_for_t*) (node->next));
		}// body is a 'for' loop

	}// if (PAST_NODE_IS_A (node, past_for))
	else if (PAST_NODE_IS_A (node, past_if))
	{
		if (PAST_NODE_IS_A (((s_past_if_t*) node)->then_clause, past_for) || PAST_NODE_IS_A (((s_past_if_t*) node)->then_clause, past_parfor))
		{
			((s_past_if_t*) node)->then_clause = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_if_t*) node)->then_clause);
		}// body is a 'for' loop

		if (PAST_NODE_IS_A (((s_past_if_t*) node)->else_clause, past_for) || PAST_NODE_IS_A (((s_past_if_t*) node)->else_clause, past_parfor))
		{
			((s_past_if_t*) node)->else_clause = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_if_t*) node)->else_clause);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_if))
	else if (PAST_NODE_IS_A (node, past_affineguard))
	{
		if (PAST_NODE_IS_A (((s_past_affineguard_t*) node)->then_clause, past_for) || PAST_NODE_IS_A (((s_past_affineguard_t*) node)->then_clause, past_parfor))
		{
			((s_past_affineguard_t*) node)->then_clause = HoistLoopBoundExpressions ((s_past_for_t*) ((s_past_affineguard_t*) node)->then_clause);
		}// body is a 'for' loop
	}// if (PAST_NODE_IS_A (node, past_if))

}// void AstOptimizer::TraverseToHoistLoopBoundExpressions (s_past_node_t* node, void* data)

void AstOptimizer::HoistExpressionsInForLoops(s_past_node_t* node)
{
	past_visitor (node, TraverseToHoistLoopBoundExpressions, NULL, NULL, NULL);
}// void AstOptimizer::HoistExpressionsInForLoops(s_past_node_t* node)
