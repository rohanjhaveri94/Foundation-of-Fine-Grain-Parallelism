/*
 * TilingDriver.cpp: This file is part of the Parametric Tiling project.
 *
 * Parametric Tiling: A CLAST-to-CLAST parametric tiling software
 *
 * Copyright (C) 2011 Sanket Tavargeri
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Sanket Tavargeri <sanket.tavargeri@gmail.com>
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include<string>
#include<iostream>
#include<vector>
#include <set>
#include<sstream>

# include <ptile/EvolveTile_outerParallel.hpp>
# include <ptile/EvolveTile_wavefrontParallel.hpp>
# include <ptile/TilingDriver.hpp>
# include <ptile/AstOptimizer.hpp>
# include <ptile/SecondLevelTiler.hpp>

  void TilingDriver::traverse_for_replace (s_past_node_t* node, void* data)
  {
    void** args = (void**)data;
    if (*args != NULL && PAST_NODE_IS_A(node, past_for))
      {
	past_replace_node (node, (s_past_node_t*)*args);
	*args = NULL;
      }
  }



  void TilingDriver::traverse_for_find_first (s_past_node_t* node, void* data)
  {
    void** args = (void**)data;
    if (*args == NULL && PAST_NODE_IS_A(node, past_for))
	*args = node;
  }


  s_past_node_t* TilingDriver::ReplaceFirstForLoopNest(s_past_node_t* ast,
					 s_past_node_t* tiledCode)
  {
    if (PAST_NODE_IS_A(ast, past_for))
      return tiledCode;

    void* data = tiledCode;
    past_visitor (ast, traverse_for_replace, (void*)&data, NULL, NULL);
    return ast;
  }

  s_past_node_t* TilingDriver::FindFirstForLoop(s_past_node_t* s)
  {
    s_past_node_t* data = NULL;
    past_visitor (s, traverse_for_find_first, (void*)&data, NULL, NULL);

    return data;
  }


  // Input: Single for loop nest
  s_past_node_t* TilingDriver::DriveTiling(s_past_node_t* inputAST,
			     scoplib_scop_p program,
			     s_ptile_options_t* options, int nofuse)
  {
    if (options->verbose_level > 2)
      std::cout << "[PTile] Computing convex hull" << std::endl;
    scoplib_scop_p scopInputToTiling =
      ConvexHullFormer::CreateConvexHull(program);

    if (options->verbose_level > 2)
      {
	printf ("[PTile] scopInputToTiling:\n");
	scoplib_scop_print (stdout, scopInputToTiling);
      }


    if (options->verbose_level > 2)
      std::cout << "[PTile] Convert convex hull to internal representation"
		<< std::endl;
    ScoplibToExpressionConverter scoplibToExpressionConverter;
    //printf("Calling scoplibToExpressionConverter\n");
    vector<Expression*> *exprs = scoplibToExpressionConverter.ReadAndParseScoplibToExpressions(scopInputToTiling);
    //printf("Returning from scoplibToExpressionConverter\n");
    s_past_node_t* pointForLoops = FindFirstForLoop(inputAST);

    if (options->verbose_level > 2)
      std::cout << "[PTile] Tiling..."
		<< std::endl;
    s_past_node_t* tiledCode = DriveTiling(exprs, pointForLoops, options, nofuse);

    if (options->verbose_level > 2)
      std::cout << "[PTile] Inserting final code"
		<< std::endl;
    // Need to insert the tiledLoops in the appropriate position
    // printf ("Calling ReplaceFirstForLoopNest\n");
    s_past_node_t* outputAST = ReplaceFirstForLoopNest(inputAST, tiledCode);
    // printf ("Returned from ReplaceFirstForLoopNest\n");

    // return (struct ext_clast_stmt*) tiledLoops;
    return outputAST;
  }// void DriveTiling(scoplib_scop_p scoplibScop, struct clast_stmt **pointLoops)





  s_past_node_t* TilingDriver::DriveTiling(vector<Expression*> *exprs,
			     s_past_node_t* pointLoops,
			     s_ptile_options_t* options, int nofuse)
  {
    Tiler tiler;
    vector<Expression*> *origExpressions = ExpressionLibrary::CopyExpressions(exprs);
    if (options->verbose_level > 2)
      std::cout << "[PTile] Generating tile loops" << std::endl;
    struct TileLoops tileLoopsStruct = tiler.Tile(exprs, options, 1, 1);
    s_past_node_t* tileLoops = tileLoopsStruct.tileLoops;

    if (options->verbose_level > 2)
      std::cout << "[PTile] Inserting tile loops" << std::endl;
    TileLoopInserter tileLoopInserter;

    if (options->verbose_level > 3)
      {
	std::cout << "[PTile] Generated tile loops:" << std::endl;
	past_pprint (stdout, tileLoops);
      }

    s_past_node_t* tiledCode = NULL;


 if (options->level == 1)
 {

     if (nofuse == 1)
     {
	// printf ("Calling InsertTileLoopsInOriginalLoopOrder\n");
        tiledCode = tileLoopInserter.InsertTileLoopsInOriginalLoopOrder(pointLoops, tileLoopsStruct, options);
	// printf ("Returned from InsertTileLoopsInOriginalLoopOrder\n");
     }
    else
     {
	tiledCode = tileLoopInserter.InsertTileLoops(pointLoops, tileLoopsStruct, options);
     }



  /*{
	FILE* fp = fopen ("Output.c", "a");
	past_pprint (fp, tiledCode);
	fclose (fp);
  }*/


   if (options->EvolveTile == 1)
   {
	// Outer loop parallel case
	if (options->RSFME == 0)
	{
		tiledCode = EvolveTileGenerator::EvolveTileCodeGenerateForOuterParallelLoop(pointLoops, tileLoops, tiledCode, options);
	}// if (options->RSFME == 0)
	else if (options->RSFME == 1)
	{
		tiledCode = EvolveWavefrontTileGenerator::EvolveTileCodeGenerateForWavefrontParallelLoop(pointLoops, tileLoops, tiledCode, options);
	}// else if (options->RSFME == 1)
   } // if (options->EvolveTile == 1)


    if (options->verbose_level > 2)
      std::cout << "[PTile] Optimizing generated code" << std::endl;

    // Apply the optimization:
    // Hoist the lowerbound & upperbound expressions for every 'for' loop
    s_past_node_t* ConditionalHoistedTiledCode = tiledCode;

   if (options->EvolveTile == 1)
   {
     AstOptimizer::HoistExpressionsInForLoops (ConditionalHoistedTiledCode);
   }// if (options->EvolveTile == 1)

  /*{
	FILE* fp = fopen ("Output.c", "a");
	past_pprint (fp, ConditionalHoistedTiledCode);
	fclose (fp);
  }*/

    return ConditionalHoistedTiledCode;
 }// if (options->level == 1)
 else if (options->level == 2)
 {
    // cout<<"Level 2 tiling"<<endl;
//    cout<<"Calling SecondLevelTiler::Tile()"<<endl;
    struct TileLoops tileLoopsStruct2 =  SecondLevelTiler::Tile(origExpressions, options);
//    cout<<"Returned from SecondLevelTiler::Tile()"<<endl;

     if (nofuse == 1 && options->RSFME == 0)
     {
	// printf ("Calling InsertTileLoopsInOriginalLoopOrder\n");
	tiledCode = SecondLevelTiler::InsertTileLoopsInOriginalLoopOrder(pointLoops, tileLoopsStruct, tileLoopsStruct2, options);
	// printf ("Returned from InsertTileLoopsInOriginalLoopOrder\n");
     }
     else
     {
//    cout<<"Calling SecondLevelTiler::InsertTileLoops"<<endl;
    tiledCode = SecondLevelTiler::InsertTileLoops(pointLoops, tileLoopsStruct, tileLoopsStruct2, options);
//    cout<<"Returned from SecondLevelTiler::InsertTileLoops"<<endl;
     }


   if (options->EvolveTile == 1)
   {
	// Outer loop parallel case
	if (options->RSFME == 0)
	{
		tiledCode = EvolveTileGenerator::EvolveTileCodeGenerateForOuterParallelLoop(pointLoops, tileLoopsStruct.tileLoops, tiledCode, options);
	}// if (options->RSFME == 0)
	else if (options->RSFME == 1)
	{
		/*
		cout<<"Tile loops: "<<endl;
		past_pprint (stdout, tileLoopsStruct.tileLoops);
		cout<<"point loops: "<<endl;
		past_pprint (stdout, pointLoops);
		cout<<"Tiled code: "<<endl;
		past_pprint (stdout, tiledCode);
		*/

		tiledCode = EvolveWavefrontTileGenerator::EvolveTileCodeGenerateForWavefrontParallelLoop(pointLoops, tileLoopsStruct.tileLoops, tiledCode, options);

		s_past_node_t* ConditionalHoistedTiledCode = tiledCode;
	        AstOptimizer::HoistExpressionsInForLoops (ConditionalHoistedTiledCode);

	}// else if (options->RSFME == 1)
   } // if (options->EvolveTile == 1)

    return tiledCode;
 }// else if (options->level == 2)
 else
 {
   assert(0);
 }


    // return tiledCode;
  }// void DriveTiling(vector<Expression*> *exprs, struct clast_stmt **pointLoops)
