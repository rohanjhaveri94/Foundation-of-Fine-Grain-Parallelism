/*
 * TilingDriver.cpp: This file is part of the Parametric Tiling project.
 *
 * Parametric Tiling: A CLAST-to-CLAST parametric tiling software
 *
 * Copyright (C) 2011 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Sanket Tavargeri <sanket.tavargeri@gmail.com>
 *
 */

# include <ptile/ExpressionLibrary.hpp>
# include <ptile/EvolveTile_outerParallel.hpp>
# include <ptile/EvolveTile_wavefrontParallel.hpp>


void EvolveTileGenerator::CollectOuterMostIteratorName (s_past_node_t* node, void* data)
{
if (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor))
   {
    vector<string>* iteratorName = (vector<string>*)data;

    if (iteratorName->size() == 0)
    {
    	s_symbol_t* VariableNode = ((s_past_for_t*) node)->iterator;
    	iteratorName->push_back (string((const char*)VariableNode->data));
    }// if (iteratorName.size() == 0)

   }// if (data == NULL && (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor)))
}// static void CollectOuterMostIteratorName (s_past_node_t* node, void* data)


void EvolveTileGenerator::CollectOuterMostIteratorLowerBound (s_past_node_t* node, void* data)
{
if (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor))
   {
    vector<s_past_node_t*>* iteratorLB = (vector<s_past_node_t*>*)data;

    if (iteratorLB->size() == 0)
    {
    	s_past_node_t* LB = ((s_past_binary_t*) (((s_past_for_t*) node)->init))->rhs;
    	iteratorLB->push_back (past_clone (LB));
    }// if (iteratorLB.size() == 0)

   }// if (data == NULL && (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor)))
}// void EvolveTileGenerator::CollectOuterMostIteratorLowerBound (s_past_node_t* node, void* data)


void EvolveTileGenerator::AddGlobalMinConstraintToOuterLoop (s_past_node_t* node, void* data)
{
	    
if (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor))
   {
	vector<string>* names = (vector<string>*) data;
	char* variableName = (char*) ((s_past_varref_t*) (((s_past_binary_t*) (((s_past_for_t*) node)->init))->lhs))->symbol->data;

	if (strcmp (variableName, names->at (0).c_str()) == 0)
	{
		s_symbol_t* iterSymb = symbol_add_from_char (NULL, names->at (1).c_str());
		s_past_node_t* minGlobalVariableNode = &past_varref_create(iterSymb)->node;
		((s_past_binary_t*) (((s_past_for_t*) node)->init))->rhs = 
			past_node_binary_create(past_max, ((s_past_binary_t*) (((s_past_for_t*) node)->init))->rhs, minGlobalVariableNode);
	}// if (strcmp (variableName, names->at (0).c_str() == 0)

   }// if (data == NULL && (PAST_NODE_IS_A (node, past_for) ||  PAST_NODE_IS_A (node, past_parfor)))

}// void EvolveTileGenerator::AddGlobalMinConstraintToOuterLoop (s_past_node_t* node, void* data)

s_past_node_t*  EvolveTileGenerator::CreateStripMinedOuterLoop (s_past_node_t* tileLoops, s_past_node_t* pointLoops, s_ptile_options_t* options)
{

	// Collect iterator names of the outermost point loop.	
	vector<string>* outerPointIteratorName = new vector<string>();
	past_visitor (pointLoops, CollectOuterMostIteratorName, (void*) outerPointIteratorName,	NULL, NULL);
        assert (outerPointIteratorName->size() == 1); // Asserting that there is only outer loop iterator

	string outerTileIteratorName = outerPointIteratorName->at (0) +  ExpressionLibrary::GetTileIteratorSuffix (1, 3);

	// Assert that the tileLoops has outer statement as the 'for' loop
	assert (PAST_NODE_IS_A (tileLoops, past_for) ||  PAST_NODE_IS_A (tileLoops, past_parfor));

	// Make a copy of the outer 'for' loop
	PAST_DECLARE_TYPED(for, originalOuterForLoop, tileLoops);
	s_past_node_t* originalBody = originalOuterForLoop->body;
	originalOuterForLoop->body = NULL;
	s_past_node_t* outerForLoopStatement = past_clone ((s_past_node_t*) originalOuterForLoop);
	PAST_DECLARE_TYPED(for, outerForLoop, outerForLoopStatement);
	// Restore
	originalOuterForLoop->body = originalBody;

	/* Manipulate the outerForLoop to get the desired strip-mined outer 'for' loop
	Change
	for (c1t1 = round((-1 + (1 / T1c1))); c1t1 <= round(((n * (1 / T1c1)) + ((1 / T1c1) * -1))); ++(c1t1)) {}
	to
	for (c1t1_tile = round((-1 + (1 / T1c1))); c1t1_tile <= round(((n * (1 / T1c1)) + ((1 / T1c1) * -1))); c1t1_tile+=T1c1_tile) {}

	- Append _tile to the iterator name
	- Change the trip count to T1<iterator_name>
	*/

	// init
	if (outerForLoop->init != NULL)
	{
		if (PAST_NODE_IS_A (outerForLoop->init, past_binary))
		{
			    s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, outerTileIteratorName.c_str());
			((s_past_binary_t*) outerForLoop->init)->lhs = &past_varref_create(iterSymb)->node;
		}// if (PAST_NODE_IS_A (outerForLoop->init, past_binary)
	}// if (outerForLoop->init != NULL)

	// test
	if (outerForLoop->test != NULL)
	{
		if (PAST_NODE_IS_A (outerForLoop->test, past_binary))
		{
			    s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, outerTileIteratorName.c_str());
			((s_past_binary_t*) outerForLoop->test)->lhs = &past_varref_create(iterSymb)->node;
		}// if (PAST_NODE_IS_A (outerForLoop->test, past_binary))
	}// if (outerForLoop->test != NULL)

	// increment
	{
	// c1t1_tile = c1t1_tile + T1c1_tile
	string outerTileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 3) +  outerPointIteratorName->at (0);
	// printf ("outerTileSizeName = %s\n", outerTileSizeName.c_str());
	s_symbol_t* iterSymb1 = symbol_add_from_char (options->symboltable, outerTileIteratorName.c_str());
	s_symbol_t* tileSizeSymb = symbol_add_from_char (options->symboltable, outerTileSizeName.c_str());
	assert (tileSizeSymb != NULL);
	s_past_node_t* addition =  past_node_binary_create(past_add, &past_varref_create(iterSymb1)->node, &past_varref_create(tileSizeSymb)->node);

	s_symbol_t* iterSymb2 = symbol_add_from_char (options->symboltable, outerTileIteratorName.c_str());
	s_past_node_t* assignment =  past_node_binary_create(past_assign, &past_varref_create(iterSymb2)->node, addition);
	outerForLoop->increment = assignment;
	}

	// iterator
	{
		s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, outerTileIteratorName.c_str());
		outerForLoop->iterator = iterSymb;
	}

	return (s_past_node_t*) outerForLoop;
}// s_past_node*  CreateStripMinedOuterLoop (s_past_node_t* tileLoops)


 s_past_node_t* EvolveTileGenerator::PrepareOuterParallelEvolveCode (s_past_node_t* stripminedOuterLoop, 
					s_past_node_t* pointLoops, s_past_node_t* tileLoops, s_past_node_t* tiledCode, s_ptile_options_t* options)
	{
		// Add the following to the body of the stripminedOuterLoop.
		/*	
			c1t1_min = c1t2;
			c1t1_max = min (c1t2 + T2c1 - 1, upperbound of stripminedOuterLoop);	
		*/

	// Collect iterator names of the outermost tile loop.	
	vector<string>* outerTileIteratorName = new vector<string>();
	past_visitor (tileLoops, CollectOuterMostIteratorName, (void*) outerTileIteratorName,	NULL, NULL);
        assert (outerTileIteratorName->size() == 1); // Asserting that there is only outer loop iterator

	// Collect iterator names of the outermost point loop.	
	vector<string>* outerPointIteratorName = new vector<string>();
	past_visitor (pointLoops, CollectOuterMostIteratorName, (void*) outerPointIteratorName,	NULL, NULL);
        assert (outerPointIteratorName->size() == 1); // Asserting that there is only outer loop iterator
	

	// c1t1_min = c1t2;
	s_past_node_t* minAssignment = NULL;

	{		
		minAssignment = past_clone (((s_past_binary_t*) (((s_past_for_t*) stripminedOuterLoop)->test))->lhs);		
	}

	// c1t1_max = min (c1t2 + T2c1 - 1, upperbound of stripminedOuterLoop);
	s_past_node_t* maxAssignment = NULL;
	{
	
	// c1t2 + T2c1 - 1
		string outerTileIteratorName2 = outerPointIteratorName->at (0) +  ExpressionLibrary::GetTileIteratorSuffix (1, 3);
		string outerTileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 3) +  outerPointIteratorName->at (0);

	s_symbol_t* tisymb = symbol_add_from_char(options->symboltable, outerTileIteratorName2.c_str());
	s_symbol_t* tssymb = symbol_add_from_char(options->symboltable, outerTileSizeName.c_str());

	    s_past_node_t* tileIteratorClastName1 =
	      &past_varref_create(tisymb)->node;
	    s_past_node_t* tileSizeClastName1 =
	      &past_varref_create(tssymb)->node;

	    u_past_value_data_t val;
	    val.intval = -1;
	    s_past_node_t* minusOne =
	      &past_value_create(e_past_value_int, val)->node;
	    
	    s_past_node_t* fullTileUBComponent1 =
	      &past_binary_create(past_add,
				  tileSizeClastName1, minusOne)->node;

	    s_past_node_t* fullTileUBComponent2 =
	      &past_binary_create(past_add, tileIteratorClastName1,
				  fullTileUBComponent1)->node;

	    s_past_node_t* fullTileUBComponent3 = past_clone (((s_past_binary_t*) (((s_past_for_t*) stripminedOuterLoop)->test))->rhs);
	    s_past_node_t* fullTileUB = past_node_binary_create(past_min, fullTileUBComponent2, fullTileUBComponent3);

		string maxName = GeneralUtilityClass::GetGlobalEstimateMax_prefix () + outerTileIteratorName->at(0);
		s_symbol_t* iterSymb = symbol_add_from_char(options->symboltable, maxName.c_str());
		s_past_node_t* type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
		s_past_node_t* declaration = 
		  past_node_vardecl_create (past_node_type_create (type),
					    past_node_varref_create(iterSymb));
		maxAssignment = past_node_statement_create (past_node_binary_create(past_assign, declaration, fullTileUB));
	}


	// Modify the first loop of the tiledCode to change its bounds to c1t2 and c1t1_max
	{
		if (PAST_NODE_IS_A (tiledCode, past_for))
		{
			((s_past_binary_t*) (((s_past_for_t*) tiledCode)->init))->rhs = minAssignment;

			string maxName = GeneralUtilityClass::GetGlobalEstimateMax_prefix() + outerTileIteratorName->at (0);
			s_symbol_t* iterSymb = symbol_add_from_char(options->symboltable, maxName.c_str());
			((s_past_binary_t*) (((s_past_for_t*) tiledCode)->test))->rhs = &past_varref_create(iterSymb)->node;	
		}// if (PAST_NODE_IS_A (tiledCode, past_for))
	}



	// Add global_c1_min = minimum of c1; statement
	s_past_node_t* globalMinStatement = NULL;
	s_past_node_t* returnStatement = NULL;

	{
		string globalMinVariableName = GeneralUtilityClass::GetGlobalEstimatePrefix() + outerPointIteratorName->at (0) + GeneralUtilityClass::GetGlobalEstimateMin_suffix();
		vector<s_past_node_t*>* lowerbound = new vector<s_past_node_t*> ();

		past_visitor (pointLoops, CollectOuterMostIteratorLowerBound, (void*) lowerbound, NULL, NULL);
		assert (lowerbound->size () == 1);

		s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, globalMinVariableName.c_str());
		s_past_node_t* type = past_node_varref_create (symbol_add_from_char (NULL, "int"));
		s_past_node_t* declaration = 
		  past_node_vardecl_create 
		  (past_node_type_create (type), past_node_varref_create(iterSymb));
		s_past_node_t* assignment =  past_node_binary_create(past_assign, declaration, lowerbound->at (0));
		globalMinStatement = past_node_statement_create (assignment);
	}


	// Add max (global_c1_min, ...) check in the point loops 
	AddGlobalMinConstraint (pointLoops, tiledCode);

	// Set parallel 'for' loop information
	
	assert (PAST_NODE_IS_A (tiledCode, past_for));
	s_past_node_t* newtree = past_for_to_parfor (tiledCode);
	maxAssignment->next = newtree;

	// Generate 'switch' code
	s_past_node_t* switchCode = GenerateSwitchCode (pointLoops, stripminedOuterLoop, outerPointIteratorName->at (0), options);
	newtree->next = switchCode;
	
	((s_past_for_t*) stripminedOuterLoop)->body = maxAssignment;

	// Hoist the upperbound so that it can be freshly assigned when the tile sizes are changed.
	// c1t2_max = UB;
	// for (c1t2 = expression; c1t2 <= c1t2_max; c1t2=c1t2+T2c1);
	s_past_node_t* UBHoistedForStripminedOuterLoop = GeneralUtilityClass::HoistBoundsOfForLoop ((s_past_for_t*) stripminedOuterLoop, options);
	
	if (globalMinStatement != NULL)
	{
		globalMinStatement->next = UBHoistedForStripminedOuterLoop;
		returnStatement = globalMinStatement;
	}// if (globalMinStatement != NULL)
	else
	{
		returnStatement = UBHoistedForStripminedOuterLoop;
	} // else

		return returnStatement;
	} //  void EvolveTileGenerator::PrepareOuterParallelEvolveCode (s_past_node_t* stripminedOuterLoop, s_past_node_t* pointLoops, s_past_node_t* tileLoops, s_past_node_t* tiledCode, s_ptile_options_t* options)


/*
If the outerPointIteratorName = c1, the function generates the following code:

if ((c1t1_max * T1c1 + T1c1 - 1) >= global_c1_min)
{
	global_c1_min = c1t1_max * T1c1 + T1c1;
	
	// Change tile sizes 
	T1c1 = T1c1;

	c1t2 = (global_c1_min - T1c1 + 1)/T1c1;
	c1t2_max = UB of stripminedOuterLoop;
	c1t2 = c1t2 - T2c1;	
}


*/
	s_past_node_t* EvolveTileGenerator::GenerateSwitchCode (s_past_node_t* pointLoops, s_past_node_t* stripminedOuterLoop, string outerPointIteratorName, s_ptile_options_t* options)
	{

		s_past_node_t* ifCondition = FormGuardConditionToSwitchCode (outerPointIteratorName, options);
		FillSwitchCodeBody (pointLoops, stripminedOuterLoop, outerPointIteratorName, ifCondition, options);
		
		return ifCondition;
	}// s_past_node_t* GenerateSwitchCode (s_past_node_t* stripminedOuterLoop, string outerPointIteratorName)




/*
If str=T1c1, the function returns
T1c1 = T1c1;
*/
s_past_node_t* EvolveTileGenerator::GetSelfAssignmentStatement (string str)
{
	s_symbol_t* iterSymb1 = symbol_add_from_char (NULL, str.c_str());
	s_symbol_t* iterSymb2 = symbol_add_from_char (NULL, str.c_str());
	s_past_node_t* assignmentStatement = past_node_statement_create (past_node_binary_create(past_assign, &past_varref_create(iterSymb1)->node, 
									&past_varref_create(iterSymb2)->node));
	return assignmentStatement;
}// s_past_node_t* GetSelfAssignmentStatement (string str)

/*
The function returns: if outerPointIteratorName = c1;
if ((c1t1_max * T1c1 + T1c1 - 1) >= global_c1_min) { }
*/
s_past_node_t* EvolveTileGenerator::FormGuardConditionToSwitchCode (string outerPointIteratorName, s_ptile_options_t* options)
{
	string c1t1_max_name = GeneralUtilityClass::GetGlobalEstimateMax_prefix() + outerPointIteratorName + ExpressionLibrary::GetTileIteratorSuffix (1, 1);
	string T1c1_name = ExpressionLibrary::GetTileSizePrefix (1, 1) + outerPointIteratorName;
	string global_c1_min_name = GeneralUtilityClass::GetGlobalEstimatePrefix() + outerPointIteratorName + GeneralUtilityClass::GetGlobalEstimateMin_suffix();

	s_past_node_t* lhsOfCondition = NULL;

	{
		s_symbol_t* iterSymb1 = symbol_add_from_char (options->symboltable, c1t1_max_name.c_str());
		s_symbol_t* iterSymb2 = symbol_add_from_char (options->symboltable, T1c1_name.c_str());
		// c1t1_max * T1c1
		s_past_node_t* workingLHS = past_node_binary_create(past_mul, &past_varref_create(iterSymb1)->node, &past_varref_create(iterSymb2)->node);
		
		// c1t1_max * T1c1 + T1c1
		s_symbol_t* iterSymb3 = symbol_add_from_char (options->symboltable, T1c1_name.c_str());	
		workingLHS = past_node_binary_create(past_add, workingLHS, &past_varref_create(iterSymb3)->node);

		// c1t1_max * T1c1 + T1c1 - 1
	       u_past_value_data_t val;
	       val.intval = -1;
	       s_past_node_t* minusOne = &past_value_create(e_past_value_int, val)->node;
		workingLHS = past_node_binary_create(past_add, workingLHS, minusOne);
		
		lhsOfCondition = workingLHS;	
	}

	s_past_node_t* rhsOfCondition = NULL;
	
	{
		// global_c1_min
		s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, global_c1_min_name.c_str());	
		rhsOfCondition = &past_varref_create(iterSymb)->node;
	}

	s_past_node_t* condition = past_node_binary_create(past_geq, lhsOfCondition, rhsOfCondition);
	s_past_node_t* ifCondition = past_node_if_create (condition, NULL, NULL);

		string commentString = "/* Switch code begins */\n";
		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		ifCondition->metainfo = (void*) comment;

	return ifCondition;
} // s_past_node_t* FormGuardConditionToSwitchCode (string outerPointIteratorName)


/*
The function adds the following body to the ifCondition

	global_c1_min = c1t1_max * T1c1 + T1c1;	
	// Change tile sizes here
	T1c1 = T1c1;
	T1c2 = T1c2;
	T1c3 = T1c3;
	c1t2 = (global_c1_min - T1c1 + 1)/T1c1;
	c1t2_max = UB of stripminedOuterLoop;
	c1t2 = c1t2 - T2c1;	

*/
void EvolveTileGenerator::FillSwitchCodeBody (s_past_node_t* pointLoops, s_past_node_t* stripminedOuterLoop, 
						string outerPointIteratorName, s_past_node_t* ifCondition, s_ptile_options_t* options)
{
	assert (PAST_NODE_IS_A (ifCondition, past_if));

	string c1t1_max_name = GeneralUtilityClass::GetGlobalEstimateMax_prefix() + outerPointIteratorName + ExpressionLibrary::GetTileIteratorSuffix (1, 1);
	string T1c1_name = ExpressionLibrary::GetTileSizePrefix (1, 1) + outerPointIteratorName;
	string global_c1_min_name = GeneralUtilityClass::GetGlobalEstimatePrefix() + outerPointIteratorName + GeneralUtilityClass::GetGlobalEstimateMin_suffix();
	string c1t2_name = outerPointIteratorName + ExpressionLibrary::GetTileIteratorSuffix (1, 3);
	string c1t2_max_name = GeneralUtilityClass::GetGlobalEstimateMax_prefix() + c1t2_name;
	string T2c1_name = ExpressionLibrary::GetTileSizePrefix (1, 3) + outerPointIteratorName;
	
	s_past_node_t* body = NULL;
	// global_c1_min = c1t1_max * T1c1 + T1c1;	
	{
		s_symbol_t* iterSymb1 = symbol_add_from_char (options->symboltable, c1t1_max_name.c_str());
		s_symbol_t* iterSymb2 = symbol_add_from_char (options->symboltable, T1c1_name.c_str());
		// c1t1_max * T1c1
		s_past_node_t* workingRHS = past_node_binary_create(past_mul, &past_varref_create(iterSymb1)->node, &past_varref_create(iterSymb2)->node);
		
		// c1t1_max * T1c1 + T1c1
		s_symbol_t* iterSymb3 = symbol_add_from_char (options->symboltable, T1c1_name.c_str());	
		workingRHS = past_node_binary_create(past_add, workingRHS, &past_varref_create(iterSymb3)->node);

		// global_c1_min
		s_symbol_t* iterSymb = symbol_add_from_char (options->symboltable, global_c1_min_name.c_str());	
		s_past_node_t* workingLHS = &past_varref_create(iterSymb)->node;

		s_past_node_t* assignment = past_node_statement_create (past_node_binary_create(past_assign, workingLHS, workingRHS));

		string commentString = "\n/* Assign new tile sizes below. */";
		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		assignment->metainfo = (void*) comment;

		body = assignment;
	}


/*
	T1c1 = T1c1;
	T1c2 = T1c2;
	T1c3 = T1c3;
*/

	{


   // Collect iterator names
   vector<string>* iteratorNames = GeneralUtilityClass::CollectIteratorNames(pointLoops);

   int i;
   s_past_node_t* assignment = NULL;
   for (i = 0; i < iteratorNames->size(); ++i)
   {
	// T1c0
	string tileSizeName = ExpressionLibrary::GetTileSizePrefix(1, 1) + iteratorNames->at(i);

	// T1c0 = T1c0;
	assignment = past_node_statement_create (past_node_binary_create (past_assign, past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str())), 
									past_node_varref_create (symbol_add_from_char (NULL, tileSizeName.c_str()))));

	GeneralUtilityClass::GetLastNode (body)->next = assignment;	
   }// for (i = 0; i < iteratorNames->size(); ++i)

	if (assignment != NULL)
	{
		string commentString = "\n/* Assigning new tile sizes ends */\n";
		char *comment = (char*) malloc (sizeof (char) * (commentString.length() + 1));
		strcpy (comment, commentString.c_str());
		assignment->metainfo = (void*) comment;
	}// if (assignment != NULL)
	

	}
	
	// c1t2 = (global_c1_min - T1c1 + 1)/T1c1;
	{
		// c1t2
		s_past_node_t* c1t2_node = GeneralUtilityClass::GetPastNodeFromString (c1t2_name, options);		
		// global_c1_min
		s_past_node_t* global_c1_min_name_node = GeneralUtilityClass::GetPastNodeFromString (global_c1_min_name, options);
		// T1c1
		s_past_node_t* T1c1_node1 = GeneralUtilityClass::GetPastNodeFromString (T1c1_name, options);
		s_past_node_t* T1c1_node2 = GeneralUtilityClass::GetPastNodeFromString (T1c1_name, options);
	
		s_past_node_t* workingNode = NULL;
		// global_c1_min - T1c1
		workingNode = past_node_binary_create(past_sub, global_c1_min_name_node, T1c1_node1);

	    u_past_value_data_t val;
	    val.intval = 1;
	    s_past_node_t* one = &past_value_create(e_past_value_int, val)->node;

		// global_c1_min - T1c1 + 1
		workingNode = past_node_binary_create(past_add, workingNode, one);
		
		// (global_c1_min - T1c1 + 1)/T1c1
		workingNode = past_node_binary_create(past_div, workingNode, T1c1_node2);
		
		// c1t2 = (global_c1_min - T1c1 + 1)/T1c1;
		workingNode = past_node_binary_create(past_assign, c1t2_node, workingNode);

		(GeneralUtilityClass::GetLastNode(body))->next = past_node_statement_create (workingNode);	
	}

	// c1t2_max = UB of stripminedOuterLoop;
	{
		// c1t2_max
		s_past_node_t* c1t2_max_node = GeneralUtilityClass::GetPastNodeFromString (c1t2_max_name, options);			
		s_past_node_t* UB = past_clone (((s_past_binary_t*) ((s_past_for_t*) stripminedOuterLoop)->test)->rhs);
		s_past_node_t* assignmentStatement = past_node_statement_create (past_node_binary_create(past_assign, c1t2_max_node, UB));
		(GeneralUtilityClass::GetLastNode(body))->next = assignmentStatement;
	}

	// c1t2 = c1t2 - T2c1;
	{
		s_past_node_t* c1t2_node1 = GeneralUtilityClass::GetPastNodeFromString (c1t2_name, options);
		s_past_node_t* c1t2_node2 = GeneralUtilityClass::GetPastNodeFromString (c1t2_name, options);						
		s_past_node_t* T2c1_node = GeneralUtilityClass::GetPastNodeFromString (T2c1_name, options);
		s_past_node_t* workingNode = past_node_binary_create(past_sub, c1t2_node1, T2c1_node);	
		workingNode = past_node_binary_create(past_assign, c1t2_node2, workingNode);
		(GeneralUtilityClass::GetLastNode(body))->next = past_node_statement_create (workingNode);				
	}

	((s_past_if_t*) ifCondition)->then_clause = body;
}// void EvolveTileGenerator::FillSwitchCodeBody (s_past_node_t* ifCondition)

	void EvolveTileGenerator::AddGlobalMinConstraint (s_past_node_t* pointLoops, s_past_node_t* evolvedCode)
	{
		// Collect iterator names of the outermost point loop.	
		vector<string>* outerPointIteratorName = new vector<string>();
		past_visitor (pointLoops, CollectOuterMostIteratorName, (void*) outerPointIteratorName,	NULL, NULL);
	        assert (outerPointIteratorName->size() == 1); // Asserting that there is only outer loop iterator
		
		string globalMinVariableName = GeneralUtilityClass::GetGlobalEstimatePrefix() + outerPointIteratorName->at (0) + GeneralUtilityClass::GetGlobalEstimateMin_suffix();
		outerPointIteratorName->push_back (globalMinVariableName);

		past_visitor (evolvedCode, AddGlobalMinConstraintToOuterLoop, (void*) outerPointIteratorName,	NULL, NULL);
	}// void EvolveTileGenerator::AddGlobalMinConstraint (s_past_node_t* pointLoops, s_past_node_t* evolvedCode)


void mprint (s_past_node_t* node, FILE* out)
{
	if (node->metainfo != NULL)
	{
		fprintf (out, "%s", ((char*) node->metainfo));
	}// if (node->metainfo != NULL)
}// void mprint (s_past_node_t* node, FILE* out)

 s_past_node_t* EvolveTileGenerator::EvolveTileCodeGenerateForOuterParallelLoop(s_past_node_t* pointLoops, s_past_node_t* tileLoops, 
									s_past_node_t* tiledCode, s_ptile_options_t* options)
    {

	s_past_node_t* stripminedOuterLoop = CreateStripMinedOuterLoop (tileLoops, pointLoops, options);
	s_past_node_t* evolvedCode = PrepareOuterParallelEvolveCode (stripminedOuterLoop, pointLoops, tileLoops, tiledCode, options);

	  /*{
	FILE* fp = fopen ("Output_pre.c", "a");
	past_pprint_extended_metainfo (fp, evolvedCode, mprint, NULL);
	fclose (fp);
  	  }*/

	// printf ("Enclosing in a block\n");
	// Enclose in a block
	evolvedCode = (s_past_node_t*) past_block_create (evolvedCode);
	// printf ("Outer tile loop iterator = %s, Outer point loop iterator = %s\n", outerTileIteratorName->at (0).c_str(), outerPointIteratorName->at (0).c_str());

	  /*{
	FILE* fp = fopen ("Output.c", "a");
	past_pprint_extended_metainfo (fp, evolvedCode, mprint, NULL);
	fclose (fp);
  	  }*/

	return evolvedCode;
    }// void EvolveTileGenerator::EvolveTileCodeGenerateForOuterParallelLoop()

